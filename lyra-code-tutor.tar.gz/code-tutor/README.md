# 🧝 Lyra — AI Code Tutor

> **Live on GitHub Pages — no install, no build step, no server needed.**

An interactive AI-powered coding tutor featuring Lyra, your elven guide through the world of code. Learn HTML, CSS, JavaScript, Python, SQL, Git, and more.

---

## 🚀 Deploy to GitHub Pages (5 minutes)

### Option A — Upload via GitHub website (easiest, no computer install needed)

1. Go to [github.com](https://github.com) → **New repository**
2. Name it `lyra-code-tutor`, set **Public**, click **Create repository**
3. Click **uploading an existing file** → drag ALL files from this zip in
4. Commit to `main`
5. Go to **Settings → Pages → Source → GitHub Actions**
6. Wait ~60 seconds — your tutor is live at:
   **`https://YOUR-USERNAME.github.io/lyra-code-tutor/`**

### Option B — Git CLI

```bash
cd lyra-code-tutor
git init && git add . && git commit -m "Launch Lyra"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/lyra-code-tutor.git
git push -u origin main
```
Then: Settings → Pages → Source → GitHub Actions

---

## 🔑 API Key Setup

1. Get a free key at **https://console.anthropic.com**
2. Open your live site — Lyra will ask for it automatically
3. Paste your `sk-ant-...` key
4. Key lives only in your browser tab — totally private

## ✨ Features

- 💬 AI chat with Lyra (streamed responses)
- 📚 Theory lessons with syntax-highlighted code
- 💻 In-browser code editor (CodeMirror)
- ✅ Instant test runner with pass/fail feedback
- 💡 Hint system — guides without spoiling
- 🔍 AI code review on demand
- 📈 XP & level system (Apprentice → Code Wizard)
- 📱 Mobile responsive

## 🗂 Tracks Included

🌐 HTML · 🎨 CSS · ⚡ JavaScript · 🐍 Python · 🌿 Git · 🗃️ SQL

## 📁 Structure

```
lyra-code-tutor/
├── index.html
├── css/style.css
├── js/app.js · tutor.js · lessons.js · progress.js
├── assets/avatar.png
└── .github/workflows/deploy.yml
```

MIT License
