// ============================================================
//  LYRA CODE TUTOR — AI Tutor Logic (Anthropic API)
// ============================================================

const Tutor = (() => {
  let apiKey = null;
  let conversationHistory = [];
  let currentContext = null;

  const SYSTEM_PROMPT = `You are Lyra, a friendly, encouraging coding tutor with a fantasy elf aesthetic. You have fiery red hair, bright green eyes, and pointed ears. You're passionate about teaching code and genuinely excited when students learn something new.

Your teaching style:
- Explain concepts clearly with real-world analogies
- Use concrete examples with actual runnable code
- Be encouraging but honest — celebrate progress, gently correct mistakes
- Never just give away answers to challenges; instead guide with hints
- Use emojis sparingly but effectively (✨ 💡 🎯 🐛 🚀)
- Keep responses concise but thorough
- When showing code, always use proper markdown code blocks with language labels
- If someone is stuck, break the problem into smaller steps
- Praise good practices (descriptive variable names, comments, clean code)
- Point out common pitfalls before they happen

Personality traits:
- Warm, patient, and never condescending
- Gets genuinely excited about elegant solutions
- Has a gentle sense of humor
- References the magic of code (you can literally make things appear on screen!)
- Celebrates "aha!" moments

When reviewing code:
1. Start with what they did RIGHT
2. Explain any issues clearly
3. Offer the corrected version
4. Explain WHY the correction matters

You are running inside a web app called "Lyra Code Tutor". The student may ask about HTML, CSS, JavaScript, Python, SQL, Git, algorithms, or general programming concepts.`;

  function setApiKey(key) {
    apiKey = key.trim();
    sessionStorage.setItem('lyra_api_key', apiKey);
  }

  function getApiKey() {
    if (!apiKey) apiKey = sessionStorage.getItem('lyra_api_key');
    return apiKey;
  }

  function setContext(ctx) {
    currentContext = ctx;
    conversationHistory = [];
  }

  function clearContext() {
    currentContext = null;
    conversationHistory = [];
  }

  async function chat(userMessage, onChunk) {
    const key = getApiKey();
    if (!key) throw new Error('NO_API_KEY');

    conversationHistory.push({ role: 'user', content: userMessage });

    let systemPrompt = SYSTEM_PROMPT;
    if (currentContext) {
      systemPrompt += `\n\nCurrent lesson context:\nTrack: ${currentContext.track}\nLesson: ${currentContext.lesson}\nChallenge: ${currentContext.challenge || 'none'}`;
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        system: systemPrompt,
        messages: conversationHistory,
        stream: true,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      if (response.status === 401) throw new Error('INVALID_KEY');
      throw new Error(err.error?.message || `API error ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            if (parsed.type === 'content_block_delta' && parsed.delta?.type === 'text_delta') {
              const text = parsed.delta.text;
              fullText += text;
              if (onChunk) onChunk(text);
            }
          } catch {}
        }
      }
    }

    conversationHistory.push({ role: 'assistant', content: fullText });
    return fullText;
  }

  async function reviewCode(code, challenge, onChunk) {
    const prompt = `The student submitted this code for the challenge: "${challenge.title}"

Challenge description: ${challenge.description}

Student's code:
\`\`\`
${code}
\`\`\`

Please review their code. First check if it looks correct. Point out what they did well, any issues you see, and explain any concepts they might be missing. Be encouraging!`;

    return chat(prompt, onChunk);
  }

  async function getHint(code, challenge, failedTests, onChunk) {
    const failedList = failedTests.map(t => `- ${t}`).join('\n');
    const prompt = `The student is working on: "${challenge.title}"

Their current code:
\`\`\`
${code}
\`\`\`

These tests are failing:
${failedList}

Give them a helpful hint without giving away the full answer. Guide them to the solution step by step. Be encouraging!`;

    return chat(prompt, onChunk);
  }

  async function explainConcept(concept, onChunk) {
    return chat(`Can you explain ${concept} to me? Give me a clear explanation with a simple example.`, onChunk);
  }

  return { setApiKey, getApiKey, setContext, clearContext, chat, reviewCode, getHint, explainConcept };
})();

window.Tutor = Tutor;
